# 学术写作智能体 更新日志

## 1.0.0

- 首次入库：从 qiye-app `gaoxiaofenzhi` @ `dc861832` 迁入方案仓库。
